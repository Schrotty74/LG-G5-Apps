# G5 System Monitor — Homebrew-App 0.9.2

Eine webOS-TV-App im Stil der besprochenen dunklen Vorschau, für LG G5/webOS 25 mit Homebrew Channel. **Version 0.9.2 ist noch nicht auf dem G5 getestet.** Version 0.9.1 wurde vom Nutzer auf dem G5 ausgeführt; dabei fiel ein zu harter Schatten unter den Kacheln auf. Frühere Funktionen wurden ebenfalls auf dem Fernseher geprüft. SSH-Screenshots bestätigten ARM64, Linux 5.4.268, `/proc/stat`, RAM/Swap und `top`.

## Eigenschaften

- CPU-Auslastung (Differenz aus `/proc/stat`), RAM-Auslastung aus `/proc/meminfo`, Systemlaufzeit und Kernelversion
- Modellname, webOS-TV-/SDK-Version, Firmware und Boardkennung über den webOS-Systemproperty-Dienst
- Belegte und freie Kapazität erkannter Dateisysteme sowie aktive Netzwerkschnittstellen, IPv4-Adressen und Standard-Gateway
- Prüfung auf Root-UID 0
- CPU- und RAM-Verlauf mit bis zu 30 Messungen
- Aktualisierungsintervall wählbar zwischen 3, 5 und 10 Sekunden
- Speicherbelegung erkannter Dateisysteme als Balken
- Prozessübersicht der ersten 10 von `top` gelieferten Prozesse sowie Swap-Belegung; falls Ausgabe abweicht: `nicht verfügbar`
- Keine dauerhaften Hintergrundprozesse, keine Änderungen am Dateisystem, kein Netzwerkserver
- Firmware- und SDK-Version über den webOS-Systemproperty-Dienst; keine Temperatur-Kachel, da am getesteten G5 kein Sensorwert gefunden wurde
- TV-geeignete Oberfläche und fokussierbare Schaltfläche

## Voraussetzungen

- Root und Homebrew Channel auf dem Fernseher
- `org.webosbrew.hbchannel.service/exec` für die App erreichbar (wird auf dem G5 geprüft)
- Zum Paketbau: LG webOS CLI mit `ares-package` in einer geeigneten Entwicklungsumgebung (z. B. ChatGPT Work, falls dort CLI verfügbar ist). Für das Installieren: SSH sicher einrichten und die Installation nach der offiziellen Anleitung durchführen.

## Erstellen

```sh
ares-package ./app -o ./dist
```

Das `.ipk` aus `dist` installieren und App `org.schrotty74.g5systemmonitor` starten. Die Installation erfolgt erst nach ausdrücklicher Zustimmung; zunächst weder Systemdateien noch Root-Startskripte verändern.

## Noch zu prüfen

1. Rückgabewerte und Rechte des Homebrew-Luna-Service beim Aufruf aus dieser Dritt-App auf dem konkreten G5
2. Aktualisierung bei längerem Betrieb und Verhalten im Energiesparmodus
3. Optional CPU-/SoC-Temperatursensor und Modell-/Firmwareinfo nach schreibgeschützter SSH-Inventur ergänzen
4. Geräteprüfung vor offizieller Verteilung

## Sicherheit

Die App ruft ausschließlich einen fest kodierten lesenden Shell-Befehl über den bereits vorhandenen Homebrew-Dienst auf. Die Root-Exec-Schnittstelle ist privilegiert; es gibt deshalb keine frei eingebbaren Befehle in der App. Für Remote-Zugriff besser SSH mit Schlüsseln nutzen, nicht Telnet. Kein Autostart. Keine Netzfreigabe ins Internet.

## Stand 0.3.0

- Homebrew-Luna-Endpunkt und Antwortfelder gegen die Homebrew-Channel-Dokumentation geprüft.
- Prozessliste für wechselnde `top`-Spaltenüberschriften angepasst.
- Verspätete Antworten nach Zeitüberschreitung werden ignoriert.
- Ein `.ipk` für webOS wurde erstellt und sein Paketarchiv geprüft. `ares-package` war in der Build-Umgebung nicht verfügbar; das Paket wurde daher direkt im üblichen IPK-Archivformat erzeugt.
- Nicht am Fernseher installiert oder auf webOS 25 ausgeführt. Luna-Berechtigungen und Live-Messwerte müssen vor Ort bestätigt werden.

## Stand 0.4.0

- Pfeil hoch/runter und Bild hoch/runter scrollen auf der Dashboard-Seite, damit auch der unterhalb des sichtbaren Bereichs liegende Prozessabschnitt per Fernbedienung erreichbar ist.
- Prozessabschnitt ist fokussierbar und zeigt einen sichtbaren Fokusrahmen.

## Stand 0.5.0

- Firmware- und SDK-Version werden einmalig über `com.webos.service.tv.systemproperty/getSystemInfo` abgefragt und angezeigt.
- Temperatur ist auf dem getesteten G5 über `/sys/class/thermal` und `/sys/class/hwmon` nicht verfügbar; weitere Sensorpfade sind noch ungeprüft.

## Stand 0.6.0

- Temperatur-Kachel entfernt, da der G5 über die geprüften Schnittstellen keinen Sensorwert liefert.
- Beenden-Schaltfläche ergänzt; sie verwendet `webOS.platformBack()` und damit die webOS-Systemfunktion zum Verlassen der App.
- Zurück-Taste der Magic Remote (Keycode 461) ruft ebenfalls `webOS.platformBack()` auf.
- Mausrad- und Pointer-Wheel-Ereignisse werden direkt an den Seiten-Scroller weitergegeben, damit sich das Dashboard auch mit dem Mausrad bewegen lässt.

## Stand 0.7.0

- Modell, SDK-Version (von LG als webOS-TV-Version dokumentiert), Firmware und Boardtyp werden gemeinsam angezeigt.
- Speicherplatz wird mit `df -kP`, Netzwerkstatus über `/sys/class/net`, `ip` und ersatzweise `ifconfig` lesend abgefragt.
- Versionsnummer in App-Metadaten und IPK auf 0.7.0 erhöht.

## Stand 0.8.0

- RAM-Verlauf mit bis zu 30 Messpunkten ergänzt.
- Dateisystembelegung zusätzlich als Balken dargestellt.
- Aktualisierungsintervall kann während der Sitzung zwischen 3, 5 und 10 Sekunden wechseln.
- Abfragen bleiben lesend; die Intervallauswahl wird nicht dauerhaft gespeichert.

## Stand 0.9.0

- Dashboard-Kacheln erhalten stärkere räumliche Tiefe durch abgestufte Schatten, Glanzkanten und Perspektive.
- Fokus auf Schaltflächen hebt sie mit einem dezenten 3D-Effekt hervor; reduzierte Bewegung wird berücksichtigt.
- Keine Änderungen an Messfunktionen oder Systemzugriffen.

## Stand 0.9.1

- Speicherplatz-Einträge stellen Mount-Pfad und Kapazitätswerte untereinander dar.
- Lange Mount-Pfade umbrechen innerhalb der Kachel, statt Werte und Nachbarspalten zu überlagern.
- Messfunktionen und Systemzugriffe bleiben unverändert.

## Stand 0.9.2

- Harte, versetzte Schlagschatten entfernt, die wie eine zweite Kachelkante wirkten.
- Weiche Schatten behalten den räumlichen Eindruck ohne den Doppel-Kachel-Effekt.

Referenzen:
- https://github.com/webosbrew/webos-homebrew-channel
- https://webostv.developer.lge.com/develop/tools/cli-dev-guide

Die App nutzt primär `webOS.service.request`, sofern vorhanden, und sonst den in webOS-Apps eingebauten `PalmServiceBridge` für Luna-Anfragen. Dadurch wird keine zusätzliche webOSTV.js-Datei benötigt. Auf einer konkreten Firmware können Luna-Berechtigungen Dritt-Apps dennoch einschränken; diesen Punkt müssen wir am TV testen.

## Fortsetzung in ChatGPT Work (iPhone)

1. ZIP in Work als Projektdatei bereitstellen. Work soll `app/` prüfen, insbesondere Luna-Service-Rechte, Parsing von `top` und webOS-Kompatibilität.
2. Mit offizieller webOS CLI `ares-package ./app -o ./dist` ein IPK bauen und Dateiintegrität prüfen. Das hier bereitgestellte IPK wurde ohne `ares-package` erzeugt.
3. Vor Installation Freigabe einholen. SSH auf dem iPhone ist nicht automatisch von Work erreichbar.
4. Installation lokal durch den Nutzer per zuverlässigem Homebrew-/webOS-Installationsweg und erst danach Tests am TV.
5. Root-SSH erst durch Schlüssel absichern. Keine Passwortdaten, private IP-Adressen oder SSH-Schlüssel in Chat-/Work-Projektdateien speichern.

**Sicherheit:** Kein Löschen/Überschreiben von Systempartitionen, kein `mount -o remount`, keine OTA-Updates, kein Öffnen von Ports nach außen, kein Skript im Autostart. Die App ist als reiner Monitor vorgesehen.
