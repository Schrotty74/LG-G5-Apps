  function checkedScene(scene){
    if(scene===undefined)return [];
    if(!Array.isArray(scene)||scene.length>100)return null;
    var number=function(v,min,max){return typeof v==='number'&&isFinite(v)&&v>=min&&v<=max;};
    for(var i=0;i<scene.length;i++){
      var x=scene[i];if(!x||typeof x!=='object'||Array.isArray(x)||['rect','ellipse','polygon','image'].indexOf(x.type)<0||(x.type==='image'?(typeof x.image!=='string'||x.image.length>12000||!/^data:image\/(?:png|jpeg|webp);base64,[A-Za-z0-9+/]+={0,2}$/.test(x.image)):(typeof x.color!=='string'||!/^#[0-9a-f]{6}$/i.test(x.color))))return null;
      if(Object.keys(x).some(function(k){return ['type','color','x','y','width','height','points','opacity','animation','image'].indexOf(k)<0;}))return null;
      if(x.type==='polygon') {if(!Array.isArray(x.points)||x.points.length<3||x.points.length>40||x.points.some(function(p){return !Array.isArray(p)||p.length!==2||!number(p[0],0,1000)||!number(p[1],0,500);}))return null;}
      else if(!number(x.x,0,1000)||!number(x.y,0,500)||!number(x.width,1,1000)||!number(x.height,1,500))return null;
      if(x.opacity!==undefined&&!number(x.opacity,0,1))return null;
      if(x.animation!==undefined){var a=x.animation;if(!a||typeof a!=='object'||Array.isArray(a)||Object.keys(a).some(function(k){return ['type','duration','dx','dy','delay','rotation','fade'].indexOf(k)<0;})||['move','blink','sway','flow'].indexOf(a.type)<0||!number(a.duration,.5,60))return null;if(a.dx!==undefined&&!number(a.dx,-300,300))return null;if(a.dy!==undefined&&!number(a.dy,-300,300))return null;if(a.delay!==undefined&&!number(a.delay,-60,60))return null;if(a.rotation!==undefined&&!number(a.rotation,-360,360))return null;if(a.fade!==undefined&&typeof a.fade!=='boolean')return null;}
    }
    return scene;
  }
  var lastThemeScene='';
  function renderThemeScene(items){
    var svg=$('theme-scene');if(!svg)return;var key=JSON.stringify(items||[]);if(key===lastThemeScene)return;lastThemeScene=key;
    while(svg.firstChild)svg.removeChild(svg.firstChild);
    (items||[]).forEach(function(item){var group=document.createElementNS('http://www.w3.org/2000/svg','g');var shape=document.createElementNS('http://www.w3.org/2000/svg',item.type);shape.setAttribute('fill',item.color);shape.setAttribute('opacity',item.opacity===undefined?'1':String(item.opacity));
      if(item.type==='polygon')shape.setAttribute('points',item.points.map(function(p){return p[0]+','+p[1];}).join(' '));else if(item.type==='rect'||item.type==='image'){['x','y','width','height'].forEach(function(k){shape.setAttribute(k,String(item[k]));});if(item.type==='image')shape.setAttributeNS('http://www.w3.org/1999/xlink','href',item.image);}else{shape.setAttribute('cx',String(item.x+item.width/2));shape.setAttribute('cy',String(item.y+item.height/2));shape.setAttribute('rx',String(item.width/2));shape.setAttribute('ry',String(item.height/2));}
      if(item.animation){group.classList.add('theme-object-'+item.animation.type);group.style.setProperty('--object-duration',item.animation.duration+'s');group.style.setProperty('--object-dx',(item.animation.dx||0)+'px');group.style.setProperty('--object-dy',(item.animation.dy||0)+'px');group.style.setProperty('--object-delay',(item.animation.delay||0)+'s');group.style.setProperty('--object-rotation',(item.animation.rotation||0)+'deg');group.style.setProperty('--object-end-opacity',item.animation.fade?0:1);}group.appendChild(shape);svg.appendChild(group);
    });
  }
  function checkedTheme(t){if(!t||t.format!=='g5-theme'||t.version!==1||!/^[-a-z0-9]{1,32}$/.test(t.id)||typeof t.name!=='string'||!t.name.trim()||t.name.length>60)return null;var color=/^#[0-9a-f]{6}$/i;if(!color.test(t.background)||!color.test(t.accent)||!color.test(t.glow))return null;if(t.animation!==undefined&&['none','neon','rain','snow','particles'].indexOf(t.animation)<0)return null;var o=t.animationOptions;if(o!==undefined){if(!o||typeof o!=='object'||Array.isArray(o)||Object.keys(o).some(function(k){return ['color','duration','opacity','direction'].indexOf(k)<0;}))return null;if(o.color!==undefined&&!color.test(o.color))return null;if(o.duration!==undefined&&(typeof o.duration!=='number'||!isFinite(o.duration)||o.duration<0.5||o.duration>30))return null;if(o.opacity!==undefined&&(typeof o.opacity!=='number'||!isFinite(o.opacity)||o.opacity<0||o.opacity>1))return null;if(o.direction!==undefined&&['normal','reverse','alternate'].indexOf(o.direction)<0)return null;}var sceneData=checkedScene(t.scene);if(sceneData===null)return null;if(t.image!==undefined&&t.image!==''&&(typeof t.image!=='string'||t.image.length>70000||!/^data:image\/(?:png|jpeg|webp);base64,[A-Za-z0-9+/]+={0,2}$/.test(t.image)))return null;return {format:'g5-theme',version:1,id:t.id,name:t.name.trim(),background:t.background,accent:t.accent,glow:t.glow,image:t.image||'',animation:t.animation||'none',animationOptions:o||{},scene:sceneData};}

const fs=require('fs'), t=JSON.parse(fs.readFileSync(process.argv[2]));
if(!checkedTheme(t))throw Error('theme rejected');
for (const image of ['https://example.com/a.png','data:image/svg+xml;base64,PHN2Zz4=']) {let c=JSON.parse(JSON.stringify(t));c.scene[c.scene.length-1].image=image;if(checkedTheme(c))throw Error('unsafe image accepted');}
let c=JSON.parse(JSON.stringify(t));c.scene[c.scene.length-1].animation.rotation=361;if(checkedTheme(c))throw Error('bad animation accepted');
console.log('JavaScript validator: accepted theme and rejected unsafe inputs');
