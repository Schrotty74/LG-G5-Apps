# Teststand 0.2.91

Importierte Themes unterstützen zusätzliche eingebettete PNG-, JPEG- und WebP-Grafikelemente und den Bewegungsablauf `flow`. Dieser lässt Position, Drehung, Dauer, Verzögerung und Ausblenden begrenzt einstellen. Daten-URLs sind auf Bildformate und 12.000 Zeichen pro Objekt begrenzt; externe URLs und SVG sind nicht zugelassen. Die bestehenden Theme-Formate bleiben gültig. `china-kirschbluete-0.2.91.json` enthält ein Beispiel mit Blütenblättern.

Lokale Prüfung: Python- und JavaScript-Validator akzeptieren das neue Theme und lehnen externe URLs, SVG und ungültige Drehwerte ab. 32 bestehende Tests bestanden; JavaScript-Syntax und IPK-Dateien gegen den Quellcode geprüft. Keine Browser- oder Fernsehtests. Das Aussehen, die Animation, Import und Direct Home auf dem Fernseher sind offen. Die Test-IPK bleibt lokal und ist kein Release.

Zum Testen auf dem Fernseher vor dem Launcher-Update LG Home wiederherstellen und erst danach Direct Home bei Bedarf wieder aktivieren. Die neue Theme-Datei benötigt Teststand 0.2.91; 0.2.90 kann sie nicht importieren.
